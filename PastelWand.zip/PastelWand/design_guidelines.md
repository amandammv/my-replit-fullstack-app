# Amanda Vieira Portfolio Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from creative portfolio sites like Dribbble, Behance, and innovative design studios, emphasizing playful interactivity and visual storytelling that showcases Amanda's UI/UX expertise.

## Core Design Elements

### Color Palette
- **Primary**: 315 25% 85% (Pastel Pink) - Main brand color for headers and key elements
- **Secondary**: 200 30% 80% (Pastel Blue) - Supporting color for accents and backgrounds  
- **Tertiary**: 150 25% 82% (Pastel Green) - Highlight color for interactive elements and CTAs
- **Neutral**: 0 0% 95% (Off-white) for backgrounds, 0 0% 20% (Charcoal) for text
- **Gradients**: Subtle pink-to-blue (315 25% 85% to 200 30% 80%) for hero backgrounds and card overlays

### Typography
- **Primary**: Inter or Poppins from Google Fonts for clean, modern readability
- **Accent**: DM Sans for headings - adds personality while maintaining professionalism
- **Hierarchy**: Generous font sizes (text-4xl+ for heroes) with consistent scale

### Layout System
**Tailwind Spacing**: Primarily use units 4, 8, 16, and 24 for consistent rhythm
- Small gaps: p-4, m-4
- Medium spacing: p-8, gap-8  
- Large sections: py-16, my-16
- Extra large: py-24 for hero sections

### Component Library
- **Magic Wand Cursor**: Custom CSS cursor with animated sparkle trail
- **Floating Elements**: Subtle geometric shapes that drift across sections
- **Interactive Cards**: Portfolio pieces with hover lift effects and color transitions
- **Animated Text**: Typewriter effects for hero headlines
- **Smooth Scrolling Navigation**: Fixed header with animated underlines
- **Micro-interactions**: Button hover states, form field focus animations

## Interactive Features
- **Hero Section**: Large animated headline with floating design elements and gradient background
- **Portfolio Grid**: Masonry-style layout with hover effects revealing project details
- **Scroll Animations**: Elements fade and slide in as user scrolls
- **Contact Form**: Interactive form with animated submit button and success states

## Layout Structure
1. **Hero Section**: Full viewport with animated text, magic wand cursor prominent
2. **About Section**: Split layout with Amanda's photo and UI/UX expertise highlights  
3. **Portfolio Showcase**: Grid of projects with interactive hover states
4. **Contact Section**: Clean form with animated elements

## Images
- **Hero Background**: Subtle gradient overlay, no large hero image needed
- **Portfolio Thumbnails**: Project screenshots and mockups showcasing Amanda's UI/UX work
- **About Photo**: Professional headshot of Amanda in circular frame with pastel border
- **Decorative Elements**: Small geometric SVG shapes for visual interest

## Key Design Principles
- **Playful Professionalism**: Balance creative interactivity with clean, professional layouts
- **Color Harmony**: Use pastel palette consistently but sparingly to avoid overwhelming
- **Smooth Interactions**: All animations should be subtle and enhance rather than distract
- **Mobile-First**: Ensure magic wand cursor has appropriate mobile alternative