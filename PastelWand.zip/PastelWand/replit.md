# Amanda Vieira Portfolio

## Overview

This is a modern portfolio website for Amanda Vieira, a UI/UX designer specializing in creative digital experiences. The application is built as a single-page portfolio showcasing Amanda's work, skills, and design philosophy through an interactive, animated interface. The site emphasizes playful interactivity with magical cursor effects, smooth animations, and a pastel color palette that reflects Amanda's creative design approach.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side is built with **React** and **TypeScript**, utilizing a modern component-based architecture:

- **Build System**: Vite for fast development and optimized production builds
- **Styling**: Tailwind CSS with a custom design system based on pastel colors (pink, blue, green)
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible interface elements
- **Routing**: Wouter for lightweight client-side routing (currently single-page with smooth scrolling navigation)
- **State Management**: React Query for server state management
- **Component Structure**: Modular sections (Hero, About, Portfolio, Contact) with reusable UI components

### Backend Architecture
The server is built with **Express.js** and **TypeScript**:

- **API Design**: RESTful endpoints focused on contact form submission
- **Data Layer**: Drizzle ORM with PostgreSQL for database operations
- **Storage Strategy**: Dual storage implementation supporting both in-memory (development) and PostgreSQL (production)
- **Error Handling**: Comprehensive error handling with proper HTTP status codes and user-friendly messages

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Simple schema with users and contact_submissions tables
- **Storage Interface**: Abstract storage interface allowing for different implementations (memory vs database)

### Design System
- **Color Palette**: Pastel-based theme with primary pink (315 25% 85%), secondary blue (200 30% 80%), and tertiary green (150 25% 82%)
- **Typography**: Inter/Poppins for body text, DM Sans for headings
- **Spacing**: Consistent Tailwind spacing units (4, 8, 16, 24)
- **Interactive Elements**: Custom magic cursor with sparkle animations, hover effects, and smooth transitions

### Development Workflow
- **Development**: Hot module replacement with Vite
- **Production**: Static file serving with Express
- **Type Safety**: Full TypeScript coverage across client, server, and shared schemas
- **Component Development**: Dedicated example components for isolated development and testing

## External Dependencies

### Core Frameworks
- **React 18**: Frontend framework with modern hooks and concurrent features
- **Express.js**: Backend web framework for API endpoints
- **TypeScript**: Type safety across the entire application stack

### Database & ORM
- **PostgreSQL**: Production database (via Neon serverless)
- **Drizzle ORM**: Type-safe database operations with automatic schema generation
- **Drizzle Kit**: Database migration and schema management tools

### UI & Styling
- **Tailwind CSS**: Utility-first CSS framework with custom color system
- **Radix UI**: Headless UI primitives for accessibility and consistency
- **shadcn/ui**: Pre-built component library based on Radix UI
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Build tool and development server with hot reload
- **PostCSS**: CSS processing with Tailwind integration
- **ESBuild**: Fast JavaScript bundling for production builds

### Form Handling & Validation
- **React Hook Form**: Form state management and validation
- **Zod**: Schema validation for type-safe form data
- **Hookform Resolvers**: Integration between React Hook Form and Zod

### Additional Features
- **React Query**: Server state management and caching
- **Wouter**: Lightweight routing solution
- **Class Variance Authority**: Type-safe CSS class variants
- **Date-fns**: Date manipulation and formatting utilities