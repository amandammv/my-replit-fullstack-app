import { useState, useEffect } from 'react';
import MagicCursor from '@/components/MagicCursor';
import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import PortfolioSection from '@/components/PortfolioSection';
import ContactSection from '@/components/ContactSection';

export default function HomePage() {
  const [activeSection, setActiveSection] = useState('home');

  const handleNavigation = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleViewWork = () => {
    handleNavigation('portfolio');
  };

  // Update active section based on scroll position
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'portfolio', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <MagicCursor />
      <Navigation activeSection={activeSection} onNavigate={handleNavigation} />
      
      <main>
        <section id="home">
          <HeroSection onViewWork={handleViewWork} />
        </section>
        
        <AboutSection />
        <PortfolioSection />
        <ContactSection />
      </main>
      
      <footer className="bg-muted/30 py-8 px-4 text-center">
        <div className="max-w-6xl mx-auto">
          <p className="text-muted-foreground">
            © 2024 Amanda Vieira. Crafted with ✨ and lots of coffee.
          </p>
        </div>
      </footer>
    </div>
  );
}