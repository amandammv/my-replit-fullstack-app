import { useEffect } from 'react';

export default function MagicCursor() {
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Create magical sparkles on mouse move (more frequent for magical effect)
      if (Math.random() > 0.75) {
        const sparkle = document.createElement('div');
        const sparkleTypes = ['✨', '⭐', '💫', '🌟'];
        const randomSparkle = sparkleTypes[Math.floor(Math.random() * sparkleTypes.length)];
        
        sparkle.innerHTML = randomSparkle;
        sparkle.className = 'sparkle sparkle-animate';
        sparkle.style.left = (e.clientX + Math.random() * 20 - 10) + 'px';
        sparkle.style.top = (e.clientY + Math.random() * 20 - 10) + 'px';
        sparkle.style.fontSize = '12px';
        sparkle.style.background = 'none';
        sparkle.style.width = 'auto';
        sparkle.style.height = 'auto';
        
        document.body.appendChild(sparkle);
        
        setTimeout(() => {
          if (document.body.contains(sparkle)) {
            document.body.removeChild(sparkle);
          }
        }, 1200);
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.body.classList.add('magic-cursor');

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.body.classList.remove('magic-cursor');
    };
  }, []);

  return null;
}