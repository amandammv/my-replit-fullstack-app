import { useState } from 'react';
import { Send, Mail, MapPin, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      const result = await response.json();
      
      if (result.success) {
        alert(result.message);
        setFormData({ name: '', email: '', subject: '', message: '' });
      } else {
        alert(result.message || 'Algo deu errado. Tente novamente.');
      }
    } catch (error) {
      console.error('Contact form error:', error);
      alert('Não foi possível enviar a mensagem. Tente novamente mais tarde.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: <Mail className="w-5 h-5" />,
      label: "E-mail",
      value: "hello@amandavieira.design",
      href: "mailto:hello@amandavieira.design"
    },
    {
      icon: <Phone className="w-5 h-5" />,
      label: "Telefone",
      value: "+55 (11) 99999-9999",
      href: "tel:+5511999999999"
    },
    {
      icon: <MapPin className="w-5 h-5" />,
      label: "Localização", 
      value: "São Paulo, SP",
      href: null
    }
  ];

  return (
    <section id="contact" className="py-24 px-4 bg-gradient-to-b from-background to-primary/5">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Vamos nos <span className="text-primary">Conectar</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Pronto para dar vida às suas ideias? Eu adoraria saber sobre seu projeto e explorar como podemos trabalhar juntos.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="hover-elevate">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-6 text-foreground">Enviar uma Mensagem</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Honeypot field - hidden from users, catches spam bots */}
                <input
                  type="text"
                  name="website"
                  style={{ display: 'none' }}
                  tabIndex={-1}
                  autoComplete="off"
                />
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-sm font-medium mb-2 block">
                      Seu Nome
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="João Silva"
                      required
                      maxLength={100}
                      data-testid="input-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-sm font-medium mb-2 block">
                      Endereço de E-mail
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="joao@exemplo.com"
                      required
                      maxLength={254}
                      data-testid="input-email"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="subject" className="text-sm font-medium mb-2 block">
                    Assunto
                  </Label>
                  <Input
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    placeholder="Colaboração em Projeto"
                    required
                    maxLength={200}
                    data-testid="input-subject"
                  />
                </div>
                
                <div>
                  <Label htmlFor="message" className="text-sm font-medium mb-2 block">
                    Mensagem
                  </Label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Conte-me sobre seu projeto..."
                    className="min-h-32"
                    required
                    maxLength={2000}
                    data-testid="input-message"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full gap-2 hover-elevate"
                  disabled={isSubmitting}
                  data-testid="button-send-message"
                >
                  {isSubmitting ? 'Enviando...' : 'Enviar Mensagem'}
                  <Send className="w-4 h-4" />
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold mb-6 text-foreground">Entre em Contato</h3>
              <p className="text-muted-foreground leading-relaxed mb-8">
                Estou sempre animada para discutir novas oportunidades e desafios criativos. 
                Seja se você tem um projeto específico em mente ou apenas quer conversar sobre design, 
                sinta-se à vontade para entrar em contato!
              </p>
            </div>

            <div className="space-y-4">
              {contactInfo.map((info, index) => (
                <Card key={index} className="hover-elevate">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                        {info.icon}
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">{info.label}</div>
                        {info.href ? (
                          <a 
                            href={info.href} 
                            className="text-foreground hover:text-primary transition-colors font-medium"
                            data-testid={`link-${info.label.toLowerCase()}`}
                          >
                            {info.value}
                          </a>
                        ) : (
                          <div className="text-foreground font-medium">{info.value}</div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
              <CardContent className="p-6 text-center">
                <h4 className="font-bold text-lg mb-2 text-foreground">Pronto para Começar?</h4>
                <p className="text-muted-foreground mb-4">
                  Vamos criar algo incrível juntos!
                </p>
                <Button variant="outline" className="hover-elevate" data-testid="button-schedule-call">
                  Agendar uma Conversa
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}