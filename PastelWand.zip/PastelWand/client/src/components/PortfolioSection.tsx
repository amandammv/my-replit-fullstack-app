import { useState } from 'react';
import { ExternalLink, Eye } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import mobileAppImage from '@assets/generated_images/Mobile_app_UI_mockup_1c307dad.png';
import websiteRedesignImage from '@assets/generated_images/Website_redesign_portfolio_piece_fb4bb32f.png';
import dashboardImage from '@assets/generated_images/Dashboard_UI_design_mockup_5ca7cbef.png';

export default function PortfolioSection() {
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);

  const projects = [
    {
      id: 1,
      title: "Aplicativo Móvel HealthTracker",
      description: "Um aplicativo abrangente de monitoramento de saúde com visualização intuitiva de dados e insights personalizados. Projetado para se integrar perfeitamente às rotinas diárias dos usuários enquanto fornece análises significativas de saúde.",
      image: mobileAppImage,
      tags: ["Design Mobile", "Tecnologia de Saúde", "Visualização de Dados", "Pesquisa de Usuário"],
      category: "Aplicativo Móvel",
      results: "150% de aumento no engajamento do usuário",
      duration: "6 meses",
      role: "Designer UX/UI Líder",
      challenge: "Dados médicos complexos precisavam ser apresentados de forma acessível e não intimidante para usuários do dia a dia.",
      solution: "Criei uma interface de divulgação progressiva com elementos de gamificação para incentivar o monitoramento consistente da saúde."
    },
    {
      id: 2,
      title: "Redesign de Plataforma E-commerce", 
      description: "Redesign completo de um marketplace online focando na otimização de conversão e experiência do usuário. Simplificou o processo de checkout e melhorou a descoberta de produtos através de filtragem avançada e personalização.",
      image: websiteRedesignImage,
      tags: ["Web Design", "E-commerce", "Pesquisa UX", "Teste A/B"],
      category: "Plataforma Web",
      results: "40% de aumento na taxa de conversão",
      duration: "4 meses",
      role: "Designer UX Sênior",
      challenge: "Altas taxas de abandono de carrinho e experiência mobile ruim estavam impactando significativamente a receita.",
      solution: "Redesenhei toda a jornada do usuário com foco em sinais de confiança, navegação simplificada e abordagem mobile-first."
    },
    {
      id: 3,
      title: "Dashboard de Análises",
      description: "Dashboard de análises limpo e poderoso para empresas SaaS acompanharem métricas e insights principais. Transformou dados complexos em insights acionáveis através de arquitetura de informação cuidadosa e hierarquia visual.",
      image: dashboardImage,
      tags: ["Design de Dashboard", "SaaS", "Análise de Dados", "Design de Informação"],
      category: "Software Empresarial",
      results: "Reduziu o tempo de decisão em 60%",
      duration: "8 meses",
      role: "Designer de Produto",
      challenge: "Usuários estavam sobrecarregados pela complexidade dos dados e não conseguiam encontrar insights acionáveis rapidamente.",
      solution: "Implementei uma arquitetura de informação em camadas com widgets personalizáveis e narrativa inteligente de dados."
    }
  ];

  const handleProjectClick = (projectId: number) => {
    console.log(`Viewing project ${projectId} details`);
    // TODO: In real app, open project detail modal or navigate to project page
  };

  return (
    <section id="portfolio" className="py-24 px-4 bg-gradient-to-b from-muted/30 to-background relative overflow-hidden">
      {/* Subtle magical background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-2 h-2 bg-primary/20 rounded-full animate-pulse" style={{ animationDelay: '0s' }} />
        <div className="absolute top-32 right-20 w-1 h-1 bg-accent/30 rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
        <div className="absolute bottom-40 left-1/4 w-1.5 h-1.5 bg-chart-3/25 rounded-full animate-pulse" style={{ animationDelay: '4s' }} />
        <div className="absolute bottom-20 right-1/3 w-1 h-1 bg-primary/15 rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
      </div>
      
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-6">
            <span className="text-2xl">✨</span>
            <span className="text-sm font-medium text-primary">Portfólio</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-primary">Estudos de Caso</span> Selecionados
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Explorações aprofundadas de desafios de design, processos criativos e impacto mensurável em diversas experiências digitais
          </p>
        </div>

        <div className="space-y-12">
          {projects.map((project, index) => (
            <Card 
              key={project.id} 
              className="group hover-elevate cursor-pointer transition-all duration-500 overflow-hidden border-l-4 border-l-primary/30 hover:border-l-primary"
              onMouseEnter={() => setHoveredProject(index)}
              onMouseLeave={() => setHoveredProject(null)}
              onClick={() => handleProjectClick(project.id)}
              data-testid={`card-project-${project.id}`}
            >
              <div className="grid lg:grid-cols-2 gap-8">
                <div className="relative overflow-hidden order-2 lg:order-1">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-64 lg:h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t from-primary/60 via-transparent to-transparent flex items-end justify-center p-6 transition-opacity duration-300 ${
                    hoveredProject === index ? 'opacity-100' : 'opacity-0'
                  }`}>
                    <Button variant="secondary" size="sm" className="gap-2 backdrop-blur-sm">
                      <Eye className="w-4 h-4" />
                      Ver Estudo de Caso
                    </Button>
                  </div>
                </div>
                
                <CardContent className="p-8 order-1 lg:order-2">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary" className="text-xs">
                        {project.category}
                      </Badge>
                      <div className="text-xs text-muted-foreground">
                        {project.duration} • {project.role}
                      </div>
                    </div>
                    <ExternalLink className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  
                  <h3 className="font-bold text-2xl mb-3 text-foreground group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                  
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    {project.description}
                  </p>
                  
                  <div className="space-y-4 mb-6">
                    <div>
                      <h4 className="font-semibold text-sm text-foreground mb-2">Desafio</h4>
                      <p className="text-sm text-muted-foreground">{project.challenge}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-foreground mb-2">Solução</h4>
                      <p className="text-sm text-muted-foreground">{project.solution}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, tagIndex) => (
                      <Badge key={tagIndex} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-4 rounded-lg">
                    <div className="text-sm font-medium text-primary mb-1">Impacto</div>
                    <div className="text-lg font-bold text-foreground">{project.results}</div>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="hover-elevate" data-testid="button-view-all-work">
            Ver Todos os Trabalhos
          </Button>
        </div>
      </div>
    </section>
  );
}