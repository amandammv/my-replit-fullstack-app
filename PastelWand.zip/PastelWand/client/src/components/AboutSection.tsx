import { Heart, Lightbulb, Users, Zap } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import amandaImage from '@assets/generated_images/Amanda_Vieira_professional_headshot_97f3a3ba.png';

export default function AboutSection() {
  const skills = [
    {
      icon: <Lightbulb className="w-6 h-6" />,
      title: "Solução Criativa de Problemas",
      description: "Transformando desafios complexos em soluções elegantes e amigáveis ao usuário"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Design Centrado no Usuário",
      description: "Colocando os usuários no centro de cada decisão de design através de pesquisa e empatia"
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Prototipagem Interativa",
      description: "Dando vida às ideias com protótipos de alta fidelidade e animações fluidas"
    },
    {
      icon: <Heart className="w-6 h-6" />,
      title: "Sistemas de Design",
      description: "Criando linguagens de design escaláveis que mantêm consistência entre produtos"
    }
  ];

  return (
    <section id="about" className="py-24 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Sobre <span className="text-primary">Amanda</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Uma designer apaixonada com mais de 5 anos de experiência criando magia digital
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div className="text-center md:text-left">
            <Avatar className="w-64 h-64 mx-auto md:mx-0 mb-8 border-4 border-primary/20">
              <AvatarImage src={amandaImage} alt="Amanda Vieira" />
              <AvatarFallback className="text-6xl">AV</AvatarFallback>
            </Avatar>
          </div>
          
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground">
              Designer, Sonhadora, Solucionadora de Problemas
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Acredito que um bom design é invisível—ele simplesmente funciona. Minha jornada começou com uma curiosidade sobre 
              como as pessoas interagem com a tecnologia, e isso me levou a me especializar em criar experiências que 
              são intuitivas e encantadoras.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Quando não estou criando, você me encontrará esboçando novas ideias, explorando tendências de design, ou 
              colaborando com equipes para dar vida a conceitos inovadores. Estou sempre animada para enfrentar 
              novos desafios e expandir os limites do que é possível no design digital.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <Card key={index} className="hover-elevate cursor-pointer transition-all duration-300" data-testid={`card-skill-${index}`}>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                  {skill.icon}
                </div>
                <h4 className="font-semibold mb-2 text-foreground">{skill.title}</h4>
                <p className="text-sm text-muted-foreground">{skill.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}