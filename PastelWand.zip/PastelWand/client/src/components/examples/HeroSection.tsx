import HeroSection from '../HeroSection';

export default function HeroSectionExample() {
  const handleViewWork = () => {
    console.log('View work clicked');
  };

  return <HeroSection onViewWork={handleViewWork} />;
}