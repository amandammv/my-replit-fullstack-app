import { useState } from 'react';
import Navigation from '../Navigation';

export default function NavigationExample() {
  const [activeSection, setActiveSection] = useState('home');

  return (
    <Navigation 
      activeSection={activeSection} 
      onNavigate={setActiveSection}
    />
  );
}