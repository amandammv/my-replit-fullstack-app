import MagicCursor from '../MagicCursor';

export default function MagicCursorExample() {
  return <MagicCursor />;
}