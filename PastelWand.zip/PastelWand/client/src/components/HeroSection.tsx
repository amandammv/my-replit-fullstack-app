import { useState, useEffect } from 'react';
import { ArrowDown, Sparkles, Wand2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeroSectionProps {
  onViewWork: () => void;
}

export default function HeroSection({ onViewWork }: HeroSectionProps) {
  const [currentText, setCurrentText] = useState('');
  const [isTyping, setIsTyping] = useState(true);
  
  const fullText = "Criando experiências mágicas para usuários";

  useEffect(() => {
    if (!isTyping) return;

    const timer = setTimeout(() => {
      if (currentText.length < fullText.length) {
        setCurrentText(fullText.slice(0, currentText.length + 1));
      } else {
        setIsTyping(false);
      }
    }, 100);

    return () => clearTimeout(timer);
  }, [currentText, isTyping]);

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-accent/10">
      {/* Floating decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-16 h-16 bg-chart-2/20 rounded-full animate-bounce" style={{ animationDelay: '0s', animationDuration: '3s' }} />
        <div className="absolute top-40 right-32 w-12 h-12 bg-chart-3/20 rounded-full animate-bounce" style={{ animationDelay: '1s', animationDuration: '4s' }} />
        <div className="absolute bottom-40 left-32 w-20 h-20 bg-primary/20 rounded-full animate-bounce" style={{ animationDelay: '2s', animationDuration: '5s' }} />
        <div className="absolute bottom-20 right-20 w-14 h-14 bg-accent/20 rounded-full animate-bounce" style={{ animationDelay: '0.5s', animationDuration: '3.5s' }} />
      </div>

      <div className="text-center z-10 max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-center gap-3 mb-6">
          <span className="text-4xl animate-bounce" style={{ animationDuration: '2s' }}>🪄</span>
          <Sparkles className="text-accent w-8 h-8 animate-pulse" />
          <span className="text-2xl">⭐</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold mb-6">
          <span className="text-foreground">Amanda</span>
          <span className="text-primary block md:inline md:ml-4">Vieira</span>
        </h1>
        
        <div className="text-xl md:text-2xl text-muted-foreground mb-8 h-8">
          {currentText}
          {isTyping && <span className="animate-pulse">|</span>}
        </div>
        
        <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
          Designer UI/UX apaixonada por criar experiências digitais intuitivas que encantam usuários e resolvem problemas reais.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            size="lg" 
            className="px-8 py-6 text-lg hover-elevate"
            onClick={onViewWork}
            data-testid="button-view-work"
          >
            Ver Meu Trabalho
            <ArrowDown className="ml-2 w-5 h-5" />
          </Button>
          
          <Button 
            variant="outline" 
            size="lg"
            className="px-8 py-6 text-lg hover-elevate"
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            data-testid="button-get-in-touch"
          >
            Entre em Contato
          </Button>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  );
}