import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSubmissionSchema } from "@shared/schema";
import { z } from "zod";
import nodemailer from "nodemailer";

// Simple rate limiting store
const rateLimit = new Map<string, { count: number; resetTime: number }>();

// Email configuration (in production, use environment variables)
const transporter = nodemailer.createTransport({
  // For development/demo, we'll log emails instead of sending them
  // In production, configure with real SMTP settings
  streamTransport: true,
  newline: 'unix',
  buffer: true
});

async function sendContactEmail(submission: { name: string; email: string; subject: string; message: string; }) {
  try {
    const mailOptions = {
      from: '"Portfolio Contact Form" <noreply@amandavieira.design>',
      to: 'amanda@amandavieira.design', // Amanda's email
      subject: `Portfolio Contact: ${submission.subject}`,
      text: `
New contact form submission:

Name: ${submission.name}
Email: ${submission.email}
Subject: ${submission.subject}

Message:
${submission.message}

---
Sent from Amanda Vieira's portfolio website
      `,
      html: `
<h2>New Contact Form Submission</h2>
<p><strong>Name:</strong> ${submission.name}</p>
<p><strong>Email:</strong> ${submission.email}</p>
<p><strong>Subject:</strong> ${submission.subject}</p>
<hr>
<h3>Message:</h3>
<p>${submission.message.replace(/\n/g, '<br>')}</p>
<hr>
<p><em>Sent from Amanda Vieira's portfolio website</em></p>
      `
    };

    await transporter.sendMail(mailOptions);
    console.log("Contact email sent successfully");
  } catch (error) {
    console.error("Failed to send contact email:", error);
    // Don't throw - we don't want email failures to break form submission
  }
}

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const key = ip;
  const limit = rateLimit.get(key);
  
  if (!limit || now > limit.resetTime) {
    // Reset window (5 minutes)
    rateLimit.set(key, { count: 1, resetTime: now + 5 * 60 * 1000 });
    return true;
  }
  
  if (limit.count >= 3) { // Max 3 submissions per 5 minutes
    return false;
  }
  
  limit.count++;
  return true;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
      
      // Rate limiting check
      if (!checkRateLimit(clientIp)) {
        return res.status(429).json({
          success: false,
          message: "Too many submissions. Please wait a few minutes before trying again."
        });
      }
      
      // Validate the request body
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      
      // Simple honeypot check (if 'website' field is filled, it's likely spam)
      if (req.body.website && req.body.website.trim()) {
        return res.status(400).json({
          success: false,
          message: "Invalid submission."
        });
      }
      
      // Store the contact submission
      const submission = await storage.createContactSubmission(validatedData);
      
      // Send email notification to Amanda
      await sendContactEmail(validatedData);
      
      // Log minimal info (no PII in production logs)
      console.log("Contact submission processed:", {
        id: submission.id,
        timestamp: submission.createdAt
      });
      
      res.status(201).json({
        success: true,
        message: "Thank you for your message! Amanda will get back to you soon."
      });
    } catch (error) {
      console.error("Contact form error:", error);
      
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          message: "Please check your form data and try again.",
          errors: error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message
          }))
        });
      } else {
        res.status(500).json({
          success: false,
          message: "Something went wrong. Please try again later."
        });
      }
    }
  });

  // Remove the GET endpoint for security - contact submissions should not be publicly accessible
  // In a real app, this would be behind admin authentication

  const httpServer = createServer(app);

  return httpServer;
}
