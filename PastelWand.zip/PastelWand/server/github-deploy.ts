import { getUncachableGitHubClient } from './github-client.js';
import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

interface RepoOptions {
  name: string;
  description?: string;
  private?: boolean;
}

export async function createGitHubRepository(options: RepoOptions) {
  try {
    console.log('🔧 Setting up GitHub client...');
    const octokit = await getUncachableGitHubClient();
    
    // Get authenticated user
    const { data: user } = await octokit.rest.users.getAuthenticated();
    console.log(`✅ Connected to GitHub as: ${user.login}`);
    
    // Create repository
    console.log(`🏗️ Creating repository: ${options.name}...`);
    const { data: repo } = await octokit.rest.repos.createForAuthenticatedUser({
      name: options.name,
      description: options.description || 'Full-stack application created with Replit',
      private: options.private || false,
      auto_init: false
    });
    
    console.log(`✅ Repository created: ${repo.html_url}`);
    
    // Initialize git if not already done
    console.log('🔧 Initializing git repository...');
    try {
      execSync('git status', { stdio: 'ignore' });
      console.log('✅ Git already initialized');
    } catch {
      execSync('git init', { stdio: 'inherit' });
      console.log('✅ Git initialized');
    }
    
    // Create .gitignore if it doesn't exist
    const gitignorePath = '.gitignore';
    if (!fs.existsSync(gitignorePath)) {
      console.log('📝 Creating .gitignore...');
      const gitignoreContent = `# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Environment variables
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# Build outputs
dist/
build/
.next/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
logs
*.log

# Runtime data
pids
*.pid
*.seed
*.pid.lock

# Coverage directory used by tools like istanbul
coverage/

# nyc test coverage
.nyc_output

# Dependency directories
node_modules/
jspm_packages/

# TypeScript cache
*.tsbuildinfo

# Optional npm cache directory
.npm

# Optional eslint cache
.eslintcache

# Replit specific
.replit
replit.nix
.config/`;
      
      fs.writeFileSync(gitignorePath, gitignoreContent);
      console.log('✅ .gitignore created');
    }
    
    // Add remote origin
    console.log('🔗 Adding GitHub remote...');
    try {
      execSync('git remote remove origin', { stdio: 'ignore' });
    } catch {
      // Remote doesn't exist, continue
    }
    
    execSync(`git remote add origin ${repo.clone_url}`, { stdio: 'inherit' });
    console.log('✅ Remote origin added');
    
    // Configure git user if not set
    try {
      execSync('git config user.email', { stdio: 'ignore' });
    } catch {
      execSync(`git config user.email "${user.email || `${user.login}@users.noreply.github.com`}"`, { stdio: 'inherit' });
      execSync(`git config user.name "${user.name || user.login}"`, { stdio: 'inherit' });
      console.log('✅ Git user configured');
    }
    
    // Add all files
    console.log('📦 Adding files to git...');
    execSync('git add .', { stdio: 'inherit' });
    
    // Commit
    console.log('💾 Creating initial commit...');
    try {
      execSync('git commit -m "Initial commit: Full-stack application from Replit"', { stdio: 'inherit' });
      console.log('✅ Initial commit created');
    } catch (error) {
      console.log('ℹ️ No changes to commit or commit already exists');
    }
    
    // Push to GitHub
    console.log('🚀 Pushing to GitHub...');
    execSync('git branch -M main', { stdio: 'inherit' });
    execSync('git push -u origin main', { stdio: 'inherit' });
    
    console.log('🎉 Successfully cloned your app to GitHub!');
    console.log(`📱 Repository URL: ${repo.html_url}`);
    console.log(`🔗 Clone URL: ${repo.clone_url}`);
    
    return {
      success: true,
      repository: repo,
      url: repo.html_url,
      cloneUrl: repo.clone_url
    };
    
  } catch (error) {
    console.error('❌ Error creating GitHub repository:', error);
    throw error;
  }
}

// CLI usage
if (require.main === module) {
  const repoName = process.argv[2] || 'my-replit-app';
  const isPrivate = process.argv[3] === 'private';
  
  createGitHubRepository({
    name: repoName,
    description: 'Full-stack application created with Replit',
    private: isPrivate
  }).catch(console.error);
}