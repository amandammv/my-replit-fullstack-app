#!/usr/bin/env node

import { execSync } from 'child_process';
import { Octokit } from '@octokit/rest';
import * as fs from 'fs';

// GitHub client setup function
async function getGitHubClient() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('Authentication token not found');
  }

  const connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=github',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || 
                     connectionSettings?.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('GitHub not connected properly');
  }
  
  return new Octokit({ auth: accessToken });
}

async function deployToGitHub(repoName, options = {}) {
  try {
    console.log('🔧 Setting up GitHub client...');
    const octokit = await getGitHubClient();
    
    // Get authenticated user
    const { data: user } = await octokit.rest.users.getAuthenticated();
    console.log(`✅ Connected to GitHub as: ${user.login}`);
    
    // Create repository
    console.log(`🏗️ Creating repository: ${repoName}...`);
    const { data: repo } = await octokit.rest.repos.createForAuthenticatedUser({
      name: repoName,
      description: options.description || 'Full-stack application created with Replit',
      private: options.private || false,
      auto_init: false
    });
    
    console.log(`✅ Repository created: ${repo.html_url}`);
    
    // Initialize git if not already done
    console.log('🔧 Setting up git...');
    try {
      execSync('git status', { stdio: 'ignore' });
      console.log('✅ Git already initialized');
    } catch {
      execSync('git init', { stdio: 'inherit' });
      console.log('✅ Git initialized');
    }
    
    // Create .gitignore if it doesn't exist
    const gitignorePath = '.gitignore';
    if (!fs.existsSync(gitignorePath)) {
      console.log('📝 Creating .gitignore...');
      const gitignoreContent = `# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Environment variables
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# Build outputs
dist/
build/
.next/

# IDE & OS
.vscode/
.idea/
*.swp
*.swo
.DS_Store
Thumbs.db

# Logs
logs
*.log

# Replit specific
.replit
replit.nix
.config/

# TypeScript
*.tsbuildinfo

# Coverage
coverage/
.nyc_output

# Cache
.npm
.eslintcache`;
      
      fs.writeFileSync(gitignorePath, gitignoreContent);
      console.log('✅ .gitignore created');
    }
    
    // Configure git user
    try {
      execSync('git config user.email', { stdio: 'ignore' });
    } catch {
      execSync(`git config user.email "${user.email || `${user.login}@users.noreply.github.com`}"`, { stdio: 'inherit' });
      execSync(`git config user.name "${user.name || user.login}"`, { stdio: 'inherit' });
      console.log('✅ Git user configured');
    }
    
    // Remove existing origin if any
    try {
      execSync('git remote remove origin', { stdio: 'ignore' });
    } catch {
      // No existing origin, continue
    }
    
    // Add remote origin
    console.log('🔗 Adding GitHub remote...');
    execSync(`git remote add origin ${repo.clone_url}`, { stdio: 'inherit' });
    console.log('✅ Remote origin added');
    
    // Add all files
    console.log('📦 Adding files to git...');
    execSync('git add .', { stdio: 'inherit' });
    
    // Commit
    console.log('💾 Creating initial commit...');
    try {
      execSync('git commit -m "Initial commit: Full-stack application from Replit"', { stdio: 'inherit' });
      console.log('✅ Initial commit created');
    } catch (error) {
      console.log('ℹ️ No changes to commit or commit already exists');
    }
    
    // Push to GitHub
    console.log('🚀 Pushing to GitHub...');
    execSync('git branch -M main', { stdio: 'inherit' });
    execSync('git push -u origin main', { stdio: 'inherit' });
    
    console.log('\n🎉 SUCCESS! Your app has been cloned to GitHub!');
    console.log(`📱 Repository: ${repo.html_url}`);
    console.log(`🔗 Clone URL: ${repo.clone_url}`);
    
    return {
      success: true,
      repository: repo,
      url: repo.html_url,
      cloneUrl: repo.clone_url
    };
    
  } catch (error) {
    console.error('❌ Error cloning app to GitHub:', error.message);
    throw error;
  }
}

// Main execution
async function main() {
  console.log('🚀 Cloning your Replit app to GitHub...\n');
  
  const args = process.argv.slice(2);
  const repoName = args[0] || 'my-replit-app';
  const isPrivate = args.includes('--private');
  
  console.log(`📝 Repository name: ${repoName}`);
  console.log(`🔒 Private: ${isPrivate ? 'Yes' : 'No'}\n`);
  
  try {
    await deployToGitHub(repoName, {
      description: 'Full-stack application created with Replit',
      private: isPrivate
    });
    
  } catch (error) {
    console.error('\n❌ FAILED to clone app to GitHub:');
    console.error(error.message);
    console.log('\n💡 Troubleshooting:');
    console.log('- Make sure the GitHub integration is properly connected');
    console.log('- Check if the repository name is available');
    console.log('- Ensure you have permission to create repositories');
    process.exit(1);
  }
}

main().catch(console.error);