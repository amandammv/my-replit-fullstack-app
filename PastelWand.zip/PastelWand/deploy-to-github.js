#!/usr/bin/env node

import { execSync } from 'child_process';
import { createGitHubRepository } from './server/github-deploy.js';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);

async function main() {
  console.log('🚀 Cloning your Replit app to GitHub...\n');
  
  // Get repository name from user input or use default
  const args = process.argv.slice(2);
  const repoName = args[0] || 'my-replit-app';
  const isPrivate = args.includes('--private');
  
  console.log(`📝 Repository name: ${repoName}`);
  console.log(`🔒 Private: ${isPrivate ? 'Yes' : 'No'}\n`);
  
  try {
    const result = await createGitHubRepository({
      name: repoName,
      description: 'Full-stack application created with Replit',
      private: isPrivate
    });
    
    console.log('\n🎉 SUCCESS! Your app has been cloned to GitHub!');
    console.log(`📱 Repository: ${result.url}`);
    console.log(`🔗 Clone URL: ${result.cloneUrl}`);
    console.log('\n✅ You can now share your repository link or continue development on GitHub!');
    
  } catch (error) {
    console.error('\n❌ FAILED to clone app to GitHub:');
    console.error(error.message);
    console.log('\n💡 Troubleshooting:');
    console.log('- Make sure the GitHub integration is properly connected');
    console.log('- Check if the repository name is available');
    console.log('- Ensure you have permission to create repositories');
    process.exit(1);
  }
}

if (require.main === module || import.meta.url === `file://${process.argv[1]}`) {
  main().catch(console.error);
}