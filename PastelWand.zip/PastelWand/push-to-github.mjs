#!/usr/bin/env node

import { execSync } from 'child_process';
import * as fs from 'fs';

async function pushToGitHub() {
  try {
    console.log('🚀 Pushing your complete Portuguese portfolio to GitHub...\n');
    
    // Create .gitignore if it doesn't exist
    const gitignorePath = '.gitignore';
    if (!fs.existsSync(gitignorePath)) {
      console.log('📝 Creating .gitignore...');
      const gitignoreContent = `# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Environment variables
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# Build outputs
dist/
build/
.next/

# IDE & OS
.vscode/
.idea/
*.swp
*.swo
.DS_Store
Thumbs.db

# Logs
logs
*.log

# Replit specific
.replit
replit.nix
.config/

# TypeScript
*.tsbuildinfo

# Coverage
coverage/
.nyc_output

# Cache
.npm
.eslintcache

# Deployment scripts
deploy-github.mjs
deploy-to-github.js
push-to-github.mjs
server/github-client.ts
server/github-deploy.ts
GITHUB_DEPLOYMENT_SUMMARY.md`;
      
      fs.writeFileSync(gitignorePath, gitignoreContent);
      console.log('✅ .gitignore created');
    }
    
    // Check if git is initialized
    try {
      execSync('git status', { stdio: 'ignore' });
      console.log('✅ Git repository detected');
    } catch {
      console.log('🔧 Initializing git...');
      execSync('git init', { stdio: 'inherit' });
    }
    
    // Check if remote exists
    try {
      const remotes = execSync('git remote -v', { encoding: 'utf8' });
      if (!remotes.includes('origin')) {
        console.log('🔗 Adding GitHub remote...');
        execSync('git remote add origin https://github.com/amandammv/my-replit-fullstack-app.git', { stdio: 'inherit' });
      } else {
        console.log('✅ GitHub remote already configured');
      }
    } catch {
      console.log('🔗 Adding GitHub remote...');
      execSync('git remote add origin https://github.com/amandammv/my-replit-fullstack-app.git', { stdio: 'inherit' });
    }
    
    // Add all files
    console.log('📦 Adding all files...');
    execSync('git add .', { stdio: 'inherit' });
    
    // Commit with meaningful message
    console.log('💾 Creating commit...');
    try {
      execSync('git commit -m "Complete Portuguese Brazilian portfolio with all translations and features\n\n- Translated all UI text to Portuguese Brazil\n- Updated contact info for Brazilian audience\n- Maintained full functionality and design\n- Ready for Brazilian users"', { stdio: 'inherit' });
      console.log('✅ Commit created successfully');
    } catch (error) {
      console.log('ℹ️ No new changes to commit');
    }
    
    // Set branch to main
    console.log('🌿 Setting main branch...');
    execSync('git branch -M main', { stdio: 'inherit' });
    
    // Push to GitHub
    console.log('🚀 Pushing to GitHub...');
    execSync('git push -u origin main --force', { stdio: 'inherit' });
    
    console.log('\n🎉 SUCCESS! Your complete Portuguese portfolio is now on GitHub!');
    console.log('📱 Repository: https://github.com/amandammv/my-replit-fullstack-app');
    console.log('🇧🇷 Ready for Brazilian users!');
    
    return { success: true };
    
  } catch (error) {
    console.error('\n❌ Error pushing to GitHub:', error.message);
    throw error;
  }
}

pushToGitHub().catch(console.error);